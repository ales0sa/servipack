@extends('layouts.public')

@section('content')
    <?php
      $categorias  = [];
      $marcas      = [];
      $home        = [  ];
      $companyData =  new stdClass();
      $companyData->header_direccion = 'test';
      $companyData->header_email = 'info@servipackembalajes.com.ar';
      $companyData->header_telefono  = '11-3678-6440';
      $companyData->header_direccion = 'test';
      $companyData->header_logo  = '/logo.png';
      $active = 'website';

      $home = \App\Models\Home::find(1);
      
      
    ?>
    <div class="header__headband">
    <div class="container">
        <div class="row">
            <div class="col-md-9 d-flex">
                
                <div class="header__headband-item">
                    <i class="fas fa-envelope"></i>
                    {{ $companyData->header_email }}
                </div>
                <div class="header__headband-item">
                    <i class="fas fa-phone-alt"></i>
                    {{ $companyData->header_telefono }}
                </div>
            </div>
            <div class="col-md-2 d-flex justify-content-end">
              
              <div class="" style="
                background: rgb(0, 175, 239);
                color: white;
                font-size: 12px;
                font-weight: bold;
                padding-right: 14px;
                padding-left: 14px;"
              >

              COTIZACION
              </div>

                <div class="header__headband-networks">
                    <a href="" class="header__headband-item">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="" class="header__headband-item">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="header__navbar">
    <div class="container">
        <div class="row" style="margin-top: 9px; ">
            <a href="{{ route('website') }}" class="col col-md-4 text-center text-md-start">
                <img src="{{ $companyData->header_logo }}" alt="" class="img-fluid pb-3" width="290px" >
            </a>
            <div class="col-md-8 header__navbar-collapse">
                <a href="{{ route('website') }}" class="header__navbar-item {{ __active($active, 'website', 'header__navbar-item--active') }}">HOME</a>
                <a href="{{ route('website.empresa') }}" class="header__navbar-item {{ __active($active, 'website.empresa', 'header__navbar-item--active') }}">EMPRESA</a>
                <a href="{{ route('website.productos') }}" class="header__navbar-item {{ __active($active, 'website.productos', 'header__navbar-item--active') }}">Productos</a>
                <a href="{{ route('website.cart') }}" class="header__navbar-item {{ __active($active, 'website.cart', 'header__navbar-item--active') }}">CLIENTES</a>
                <a href="{{ route('website.contacto') }}" class="header__navbar-item {{ __active($active, 'website.contacto', 'header__navbar-item--active') }}">contacto</a>
                @if ( !auth()->check() )
                <div class="header__navbar-item header__navbar-item--no-hover">
                    <a href="{{ route('website.clientes') }}" class="btn-clients-area"><i class="fas fa-user"></i> Area de Clientes</a>
                </div>
                @else
                <div class="dropdown header__navbar-item header__navbar-item--no-hover">
                    <div class="header__navbar-user dropdown-toggle" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user me-2"></i> {{ auth()->user()->fullname }}</div>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="{{ route('website.clientes.logout') }}"><i class="fas fa-sign-out-alt"></i> SALIR</a></li>
                    </ul>
                </div>
                @endif
            </div>
            <div class="col-auto d-flex align-items-center d-md-none">
                <button type="button" id="toggle-mobile-menu" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fas fa-bars"></i></button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header py-0">
            <img src="{{ $companyData->header_logo }}" alt="" style="max-width: 160px;">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="list-group">
            <a href="{{ route('website') }}" class="list-group-item list-group-item-action  {{ __active($active, 'website.home', 'active') }}" style="border-radius: 0;">HOME</a>
            <a href="{{ route('website.empresa') }}" class="list-group-item list-group-item-action  {{ __active($active, 'website.empresa', 'active') }}">EMPRESA</a>
            <a href="{{ route('website.productos') }}" class="list-group-item list-group-item-action  {{ __active($active, 'website.productos', 'active') }}">PRODUCTOS</a>
            <a href="{{ route('website.cart') }}" class="list-group-item list-group-item-action  {{ __active($active, 'website.cart', 'active') }}">COTIZAR</a>
            <a href="{{ route('website.contacto') }}" class="list-group-item list-group-item-action  {{ __active($active, 'website.contacto', 'active') }}">CONTACTO</a>
        </div>
      </div>
    </div>
</div>

    @include('components.carousel', ['data' => \App\Models\SlidersHome::get()])

    <div class="row" style="background: #00AFEF; height: 110px;">
    </div>
    <div class="container mb-5">
        <h3 class="block-title mb-5 mt-5">NUESTRAS CATEGORÍAS</h3>
        <div class="category-list">
            @foreach ($categorias as $item)
            <a href="{{ route('website.productos.grupo', $item->id) }}" class="category-list__item" style="background-color: {{ $item->color }};">
                <div class="category-list__overlay"></div>
                <div class="category-list__container">
                    @if ($item->image)
                        <img src="{{ $item->image['url'] }}" alt="">
                    @else
                        <img src="" alt="">
                    @endif
                    <span>{{ $item->name }}</span>
                </div>
            </a>
            @endforeach
        </div>
    </div>
    <div class="home__marcas">
        <div class="container">
            
            <slick images="{{ json_encode($marcas) }}"></slick>
        </div>
    </div>
    <div class="home__promo">
        <div class="container">
            <div class="row">
                
                <div class="col-md-8 home__promo-right">
                    <div class="home__promo-text1">
                    {{ $home->input_1 }}
                        
                    </div>
                    <div class="home__promo-text2">
                    {{ $home->input_2 }}
                    </div>
                    <div class="home__promo-text3">
                    {{ $home->input_3 }}
                    </div>
                </div>
                <div class="col-md-4"  style=" 
                        background-image:url({{ $home->promo_image }});
                        background-size:cover;
                        background-repeat:no-repeat;
                        height:396px;
                        background-position:center;
                        ">
                </div>
            </div>
        </div>
    </div>
@endsection