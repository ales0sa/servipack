<?php $__env->startSection('content'); ?>
<div class="row-fluid breadcrumbs">
    <div class="container">

        <i class="fa fa-home"></i> Productos / <?php echo e($categoria->title); ?>

    </div>
</div>
<div class="container mb-5">
<div class="row mt-4">

<div class="col-12 col-md-4 col-lg-4">

<div class="accordion  accordion-flush" id="accordionExample">
    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="accordion-item">
            <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button <?php if($cat->id == $categoria->id): ?>  <?php else: ?> collapsed <?php endif; ?> " 
            type="button" data-bs-toggle="collapse" 
            data-bs-target="#collapse<?php echo e($cat->id); ?>" 
            aria-expanded="<?php if($cat->id == $categoria->id): ?> true <?php else: ?> false <?php endif; ?> " 
            aria-controls="collapse<?php echo e($cat->id); ?>">
               <?php echo e($cat->title); ?>

            </button>
            </h2>
            <div id="collapse<?php echo e($cat->id); ?>" 
                class="accordion-collapse <?php if($cat->id == $categoria->id): ?> collapsed  <?php else: ?>   collapse show <?php endif; ?> " aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                <?php $__currentLoopData = $cat->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="accordion-body  <?php if($cp->id == $selprod): ?> a_b_a <?php else: ?>   <?php endif; ?>" href="<?php echo e(route('website.producto', [ $cp->id ])); ?>" >
                        <div >
                                <?php echo e($cp->name); ?>

                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</div>

<div class="col-9">

</div>

</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ales0sa/Escritorio/OSOLE/servi-pack/servipack/resources/views/productos.blade.php ENDPATH**/ ?>