

<?php $__env->startSection('content'); ?>


            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard::layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ales0sa/Escritorio/OSOLE/servi-pack/servipack/vendor/ales0sa/laradash/src/../resources/views/admin/home.blade.php ENDPATH**/ ?>