
<div>
    <div id="carouselWebsite" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" data-bs-target="#carouselWebsite" data-bs-slide-to="<?php echo e($key); ?>" <?php echo $loop->first ? 'class="active" aria-current="true"' : ''; ?> aria-label="Slide <?php echo e($key); ?>"></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="carousel-inner">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>" style="background-image: url(<?php echo e($item->image); ?>)">
                <div class="carousel-item__overlay"></div>
                <div class="carousel-item__container">
                    <div class="container">
                        <div class="carousel-item__text1">
                        
                        </div>
                        <div class="carousel-item__text2">
                           
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselWebsite"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselWebsite"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</div><?php /**PATH /home/ales0sa/Escritorio/OSOLE/servi-pack/servipack/resources/views/components/carousel.blade.php ENDPATH**/ ?>