<?php $__env->startSection('content'); ?>

<div class="row-fluid breadcrumbs">
    <div class="container">

        <i class="fa fa-home"></i> Productos / <?php echo e($categoria->title); ?> / <?php echo e($producto->name); ?>

    </div>
</div>
<div class="container mb-5">
<div class="row mt-4">

<div class="col-12 col-md-4 col-lg-3">

<div class="accordion  accordion-flush" id="accordionExample">
    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="accordion-item">
            <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button <?php if($cat->id == $categoria->id): ?>  <?php else: ?> collapsed <?php endif; ?> " 
            type="button" data-bs-toggle="collapse" 
            data-bs-target="#collapse<?php echo e($cat->id); ?>" 
            aria-expanded="<?php if($cat->id == $categoria->id): ?> true <?php else: ?> false <?php endif; ?> " 
            aria-controls="collapse<?php echo e($cat->id); ?>">
               <?php echo e($cat->title); ?>

            </button>
            </h2>
            <div id="collapse<?php echo e($cat->id); ?>" 
                class="accordion-collapse <?php if($cat->id == $categoria->id): ?> collapsed  <?php else: ?>   collapse show <?php endif; ?> " aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                <?php $__currentLoopData = $cat->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="accordion-body  <?php if($cp->id == $selprod): ?> a_b_a <?php else: ?>   <?php endif; ?>" href="<?php echo e(route('website.producto', [ $cp->id ])); ?>" >
                        <div >
                                <?php echo e($cp->name); ?>

                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</div>

<div class="col-9">

<div class = "">
  <div class = "card">
    <!-- card left -->
    <div class = "product-imgs">
      <div class = "img-display">
        <div class = "img-showcase">
          <img src = "<?php echo e($producto->image); ?>" alt = "shoe image">
          <img src = "<?php echo e($producto->image); ?>" alt = "shoe image">
          <img src = "<?php echo e($producto->image); ?>" alt = "shoe image">
          <img src = "<?php echo e($producto->image); ?>" alt = "shoe image">
          
          
        </div>
      </div>
      <div class = "img-select">
        <div class = "img-item">
          <a href = "#" data-id = "1">
            <img src = "<?php echo e($producto->image); ?>" alt = "shoe image">
          </a>
        </div>
        <div class = "img-item">
          <a href = "#" data-id = "2">
            <img src = "<?php echo e($producto->image); ?>" alt = "shoe image">
          </a>
        </div>
        <div class = "img-item">
          <a href = "#" data-id = "3">
            <img src = "<?php echo e($producto->image); ?>" alt = "shoe image">
          </a>
        </div>
        <div class = "img-item">
          <a href = "#" data-id = "4">
            <img src = "<?php echo e($producto->image); ?>" alt = "shoe image">
          </a>
        </div>
      </div>
    </div>
    <!-- card right -->
    <div class = "product-content">
      <h2 class = "product-title"><?php echo e($producto->name); ?></h2>

      <div class = "product-detail">
        
        <?php echo $producto->short_desc; ?>

      </div>

      <div class = "purchase-info">
        <input class="" type = "number" min = "0" value = "1">
        <button type = "button" class = "btn">
          Al carrito <i class = "fas fa-shopping-cart"></i>
        </button>
        <button type = "button" class = "btn">Ficha
        <i class = "fas fa-download"></i> 
        </button>
      </div>

    </div>
  </div>
</div>

</div>

</div>

</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<script>
    const imgs = document.querySelectorAll('.img-select a');
const imgBtns = [...imgs];
let imgId = 1;

imgBtns.forEach((imgItem) => {
    imgItem.addEventListener('click', (event) => {
        event.preventDefault();
        imgId = imgItem.dataset.id;
        slideImage();
    });
});

function slideImage(){
    const displayWidth = document.querySelector('.img-showcase img:first-child').clientWidth;

    document.querySelector('.img-showcase').style.transform = `translateX(${- (imgId - 1) * displayWidth}px)`;
}

window.addEventListener('resize', slideImage);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ales0sa/Escritorio/OSOLE/servi-pack/servipack/resources/views/producto.blade.php ENDPATH**/ ?>