<?php $__env->startSection('content'); ?>
    <?php 

      $home = \App\Models\Home::find(1);
      
      $categorias  = \App\Models\Categorias::get();
      $starreds    = \App\Models\Productos::where('onhome', 1)->get();
      $clientes    = \App\Models\Clientes::pluck('image');
      ?>
    <?php echo $__env->make('components.carousel', ['data' => \App\Models\SlidersHome::get()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row-fluid" style="background: #00AFEF; height: 110px;">
    </div>

    <div class="container mb-5">
        <h3 class="block-title mb-2 mt-2">NUESTRAS CATEGORÍAS</h3>
        <div class="category-list">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a  href="<?php echo e(route('website.productos.grupo', $item->id)); ?>" 
                class="category-list__item">
                <div class="category-list__overlay"></div>
                <div class="category-list__container"  style="
                background-image: url(<?php echo e($item->image); ?>);
                height: 300px;
                ">
                   
                </div>
                
                <div class="category-list__title"> <?php echo e($item->title); ?> </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="home__promo">
        <div class="container">
            <div class="row">
                
                <div class="col-md-8 home__promo-right">
                    <div class="home__promo-text1">
                    <?php echo e($home->input_1); ?>

                        
                    </div>
                    <div class="home__promo-text2">
                    <?php echo e($home->input_2); ?>

                    </div>
                    <div class="home__promo-text3">
                    <?php echo e($home->input_3); ?>

                    </div>
                </div>
                <div class="col-md-4"  style=" 
                        background-image:url(<?php echo e($home->promo_image); ?>);
                        background-size:contain;
                        background-repeat:no-repeat;
                        height:396px;
                        background-position:center;
                        ">
                </div>
            </div>
        </div>
    </div>
    
    <div class="container mb-5">
        <h3 class="block-title mb-2 mt-2">PRODUCTOS DESTACADOS</h3>
        <div class="product-list" >
            <?php $__currentLoopData = $starreds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a  href="<?php echo e(route('website.producto', $item->id)); ?>" 
                class="product-list__item">
                <div class="product-list__overlay"></div>
                <div class="product-list__container"  style="
                background-image: url(<?php echo e($item->image); ?>);
                height: 250px;
                ">
                   
                </div>
                
                <div class="product-list__title"> <?php echo e($item->name); ?> </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="home__marcas">
        <div class="container">       

            <slick  images="<?php echo e(json_encode($clientes)); ?>"/>
        </div>
    </div>

    <script>
        var myCarousel = document.querySelector('#myCarousel')
        var carousel = new bootstrap.Carousel(myCarousel, {
        interval: 2000,
        wrap: false
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ales0sa/Escritorio/OSOLE/servi-pack/servipack/resources/views/welcome.blade.php ENDPATH**/ ?>