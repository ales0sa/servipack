<?php $__env->startSection('content'); ?>

<?php 
$categorias  = \App\Models\Categorias::get();
?>
<div class="row-fluid breadcrumbs">
    <div class="container">

        <i class="fa fa-home"></i> Productos
    </div>
</div>
<div class="container mb-5">

        <div class="category-list">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a  href="<?php echo e(route('website.productos.grupo', $item->id)); ?>" 
                class="category-list__item">
                <div class="category-list__overlay"></div>
                <div class="category-list__container"  style="
                background-image: url(<?php echo e($item->image); ?>);
                height: 300px;
                ">
                   
                </div>
                
                <div class="category-list__title"> <?php echo e($item->title); ?> </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ales0sa/Escritorio/OSOLE/servi-pack/servipack/resources/views/categorias.blade.php ENDPATH**/ ?>