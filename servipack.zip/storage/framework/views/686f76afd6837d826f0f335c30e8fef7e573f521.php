
<!DOCTYPE html>
<html lang="<?php echo e(App::getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset(Storage::url(__config_var('admin_favicon')))); ?>" type="image/png" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="public-path" content="<?php echo e(asset('/')); ?>">
    <meta name="storage-path" content="<?php echo e(asset(Storage::url('/'))); ?>">
    <meta name="decimal-separator" content="<?php echo e(__config_var('decimal_separator')); ?>">
    <meta name="thousands-separator" content="<?php echo e(__config_var('thousands_separator')); ?>">
    <meta name="3c3aazbg5" content="<?php echo e(floatval(ini_get('upload_max_filesize')) * 1024); ?>">
    <meta name="f983jd020" content="<?php echo e(floatval(ini_get('post_max_size')) * 1024); ?>">

    <title><?php echo e(config('app.name', 'Panel')); ?></title>



<link href="/css/layout.css" rel="stylesheet">
<link href="https://unpkg.com/primeicons/primeicons.css " rel="stylesheet">
<script src="https://kit.fontawesome.com/a82e74739c.js" crossorigin="anonymous"></script>
</head>
<body >

    <?php if(Auth::check()): ?>
    <div id="app" class="">
    </div>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/dashboard.js')); ?>?<?php echo e($assets_version); ?>" defer></script>


         <script>

            window.logo            = '<?php echo e(Storage::url(__cf("header_logo"))); ?>'
            window.authUser        = <?php echo json_encode(Auth::user());; ?>;


     </script>

<script>
  <?php if(auth()->guard()->check()): ?>
    window.Permissions = <?php echo json_encode(Auth::user()->permissions, true); ?>;
  <?php else: ?>
    window.Permissions = [];
  <?php endif; ?>
</script>

    <?php else: ?>
    <?php echo $__env->yieldContent('content'); ?>
         <script>window.authUser=null;</script>
    <?php endif; ?>


</body>

</html>
<?php /**PATH /home/ales0sa/Escritorio/OSOLE/servi-pack/servipack/vendor/ales0sa/laradash/src/../resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>