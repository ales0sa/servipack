<?php $__env->startSection('content'); ?>


<?php echo $__env->make('components.carousel', ['data' => \App\Models\SlidersEmpresa::get()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-5">

    <div class="row">
        <div class="col-6">

            <h6><?php echo e($data->input_1); ?></h6>
            <p><?php echo $data->input_2; ?></p>

        </div>
        <div class="col-6">
            <img src="<?php echo e($data->input_5); ?>" />
        </div>
    </div>
    <div class="row">
        <div class="col-6">

            <h6><?php echo e($data->input_3); ?></h6>
            <p><?php echo $data->input_4; ?></p>

        </div>
        <div class="col-6">
            <img src="<?php echo e($data->input_6); ?>" />
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ales0sa/Escritorio/OSOLE/servi-pack/servipack/resources/views/empresa.blade.php ENDPATH**/ ?>